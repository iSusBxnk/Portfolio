"use client"

import { useEffect, useState } from "react"
import { ChevronDown } from "lucide-react"

export default function TopSection() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Calculate parallax values
  const parallaxSlow = scrollY * 0.3
  const parallaxMedium = scrollY * 0.5
  const parallaxFast = scrollY * 0.8
  const fadeOut = Math.max(0, 1 - scrollY / 800)
  const fadeOutFast = Math.max(0, 1 - scrollY / 400)

  return (
    <div className="relative h-screen overflow-hidden">
      {/* Background Layer - Slowest */}
      <div
        className="absolute inset-0 bg-gradient-to-b from-orange-400 via-orange-500 to-orange-600"
        style={{
          transform: `translateY(${parallaxSlow}px)`,
          opacity: fadeOut,
        }}
      >
        {/* Sun */}
        <div
          className="absolute top-1/3 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-yellow-200 rounded-full opacity-80"
          style={{
            transform: `translate(-50%, 0) translateY(${parallaxSlow * 0.5}px)`,
            opacity: fadeOut * 0.8,
          }}
        />
      </div>

      {/* Mountain Background Layer */}
      <div
        className="absolute inset-0"
        style={{
          transform: `translateY(${parallaxSlow * 1.2}px)`,
          opacity: fadeOut,
        }}
      >
        {/* Back Mountains */}
        <svg className="absolute bottom-0 w-full h-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYEnd slice">
          <polygon
            points="0,800 200,300 400,400 600,200 800,350 1000,250 1200,400 1200,800"
            fill="rgba(139, 69, 19, 0.6)"
          />
          <polygon
            points="0,800 150,450 350,350 550,500 750,300 950,450 1200,350 1200,800"
            fill="rgba(160, 82, 45, 0.7)"
          />
        </svg>
      </div>

      {/* Middle Mountain Layer */}
      <div
        className="absolute inset-0"
        style={{
          transform: `translateY(${parallaxMedium}px)`,
          opacity: fadeOut,
        }}
      >
        <svg className="absolute bottom-0 w-full h-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYEnd slice">
          <polygon
            points="0,800 100,500 300,400 500,600 700,350 900,500 1100,400 1200,550 1200,800"
            fill="rgba(101, 67, 33, 0.8)"
          />
        </svg>
      </div>

      {/* Foreground Trees Layer */}
      <div
        className="absolute inset-0"
        style={{
          transform: `translateY(${parallaxFast}px)`,
          opacity: fadeOutFast,
        }}
      >
        {/* Trees silhouettes */}
        <div className="absolute bottom-0 left-0 w-full h-96">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="absolute bottom-0 bg-black opacity-70"
              style={{
                left: `${i * 8 + Math.random() * 5}%`,
                width: `${2 + Math.random() * 3}px`,
                height: `${60 + Math.random() * 80}px`,
                clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
              }}
            />
          ))}
        </div>
      </div>

      {/* Cliff and Character Layer */}
      <div
        className="absolute inset-0"
        style={{
          transform: `translateY(${parallaxFast * 1.2}px)`,
          opacity: fadeOutFast,
        }}
      >
        {/* Left cliff */}
        <div className="absolute bottom-0 left-0 w-1/3 h-96 bg-gradient-to-t from-black to-gray-800 opacity-90">
          <svg className="w-full h-full" viewBox="0 0 400 400" preserveAspectRatio="none">
            <polygon points="0,400 300,100 400,150 400,400" fill="currentColor" />
          </svg>
        </div>

        {/* Character silhouette on cliff */}
        <div
          className="absolute bottom-72 left-64 w-8 h-12 bg-black opacity-90"
          style={{
            clipPath:
              "polygon(40% 0%, 60% 0%, 70% 30%, 65% 50%, 75% 70%, 70% 100%, 30% 100%, 25% 70%, 35% 50%, 30% 30%)",
          }}
        />
      </div>

      {/* Main Content Layer */}
      <div
        className="absolute inset-0 flex flex-col items-center justify-center text-center z-10"
        style={{
          transform: `translateY(${parallaxMedium * 0.3}px)`,
          opacity: fadeOut,
        }}
      >
        <h1
          className="text-6xl md:text-8xl font-bold text-orange-200 mb-4 tracking-wider"
          style={{
            textShadow: "2px 2px 4px rgba(0,0,0,0.5)",
            fontFamily: "serif",
          }}
        >
          FIREWATCH
        </h1>
        <p className="text-xl md:text-2xl text-orange-100 mb-8 max-w-2xl px-4">
          Experience the beauty of nature through parallax scrolling
        </p>

        {/* Scroll indicator */}
        <div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce"
          style={{ opacity: fadeOut }}
        >
          <ChevronDown className="w-8 h-8 text-orange-200" />
          <p className="text-orange-200 text-sm mt-2">Scroll to explore</p>
        </div>
      </div>

      {/* Overlay gradient for smooth transition */}
      <div
        className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent z-20"
        style={{
          opacity: Math.min(1, scrollY / 200),
        }}
      />
    </div>
  )
}
